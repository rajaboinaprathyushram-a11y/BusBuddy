# BusBuddy Seats

A small browser-only demo for rural bus route search, seat availability, conductor seat updates, and printable ticket previews.

## Open in VS Code

1. Extract `BusBuddySeats.zip`.
2. Open the extracted `BusBuddySeats` folder in VS Code.
3. Open `index.html` with Live Server. If Live Server is not installed, install the Live Server extension first.
4. Search for Narsapur to Medak Town. Choose an available seat and use the minus button to update the available-seat count.

## Project files

- `index.html` contains the page structure.
- `style.css` controls the layout and appearance.
- `app.js` contains the sample route data and the small amount of interaction code.

The routes and stops are sample data. Replace them with verified local information before presenting. Seat-count changes are saved in the current browser using localStorage; this demo does not connect different devices or use a server/database.
