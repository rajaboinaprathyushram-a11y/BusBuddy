const stageRate = 5;

// These are sample routes and stops. Replace them with verified local data.
const routes = [
  {
    id: "312",
    from: "Narsapur",
    to: "Medak Town",
    leaves: "20 min",
    boarding: "Gram Panchayat Gate",
    seats: 14,
    base: 25,
    stages: 4,
    stops: ["Narsapur", "Lingampally", "Ramayampet", "Kuchanpally", "Medak Town"]
  },
  {
    id: "313",
    from: "Narsapur",
    to: "Toopran",
    leaves: "35 min",
    boarding: "Opposite Primary School",
    seats: 9,
    base: 20,
    stages: 4,
    stops: ["Narsapur", "Gummadidala", "Manoharabad", "Toopran"]
  },
  {
    id: "314",
    from: "Ramayampet",
    to: "Medak Town",
    leaves: "15 min",
    boarding: "Near Banyan Tree",
    seats: 11,
    base: 20,
    stages: 3,
    stops: ["Ramayampet", "Chityal", "Havelighanpur", "Medak Town"]
  },
  {
    id: "315",
    from: "Toopran",
    to: "Medak Town",
    leaves: "40 min",
    boarding: "Panchayat Office",
    seats: 8,
    base: 20,
    stages: 5,
    stops: ["Toopran", "Tupran North", "Wargal", "Medak Town"]
  },
  {
    id: "316",
    from: "Narsapur",
    to: "Gajwel",
    leaves: "30 min",
    boarding: "Market Bus Point",
    seats: 12,
    base: 20,
    stages: 4,
    stops: ["Narsapur", "Kallakal", "Pragnapur", "Gajwel"]
  },
  {
    id: "317",
    from: "Velur",
    to: "Medak Town",
    leaves: "50 min",
    boarding: "Primary School Junction",
    seats: 7,
    base: 20,
    stages: 6,
    stops: ["Velur", "Peddashankarampet", "Alladurg", "Medak Town"]
  },
  {
    id: "318",
    from: "Gajwel",
    to: "Toopran",
    leaves: "25 min",
    boarding: "Old Village Gate",
    seats: 10,
    base: 20,
    stages: 3,
    stops: ["Gajwel", "Kodakandla", "Fasalwadi", "Toopran"]
  },
  {
    id: "319",
    from: "Yellareddy",
    to: "Narsapur",
    leaves: "55 min",
    boarding: "Panchayat Square",
    seats: 6,
    base: 25,
    stages: 6,
    stops: ["Yellareddy", "Nagireddypet", "Lingampally", "Narsapur"]
  },
  {
    id: "320",
    from: "Toopran",
    to: "Hyderabad",
    leaves: "1 hr 10 min",
    boarding: "Toopran RTC Stop",
    seats: 5,
    base: 30,
    stages: 7,
    stops: ["Toopran", "Medchal", "Kompally", "Hyderabad"]
  },
  {
    id: "321",
    from: "Narsapur",
    to: "Ramayampet",
    leaves: "25 min",
    boarding: "Banyan Tree Stop",
    seats: 13,
    base: 20,
    stages: 2,
    stops: ["Narsapur", "Ramayampet", "Havelighanpur"]
  }
];

let activeRoute = routes[0];
let availableSeats = 14;
let selectedSeat = "";

const seatButtons = document.querySelectorAll(".seat.available");

function showRoute(route) {
  activeRoute = route;
  selectedSeat = "";

  const savedCount = localStorage.getItem("busbuddy-" + route.id);

  if (savedCount === null) {
    availableSeats = route.seats;
  } else {
    availableSeats = Number(savedCount);
  }

  document.querySelector("#route-number").textContent = "#" + route.id;
  document.querySelector("#depart-in").textContent = route.leaves;
  document.querySelector("#route-from").textContent = route.from;
  document.querySelector("#route-to").textContent = route.to;
  document.querySelector("#boarding-point").textContent = route.boarding;

  const routeStops = document.querySelector("#route-stops");

  if (routeStops) {
    routeStops.textContent = route.stops.join(" → ");
  }

  document.querySelector("#search-message").textContent =
    "Showing Route #" + route.id + " with " + route.stops.length + " listed stops.";

  updateSeatCount();
  updateTicket();
}

function updateSeatCount() {
  document.querySelector("#seat-count").textContent = availableSeats;
  document.querySelector("#control-count").textContent = availableSeats;
}

function updateTicket() {
  const fare = activeRoute.base + activeRoute.stages * stageRate;

  document.querySelector("#ticket-route").textContent = "#" + activeRoute.id;
  document.querySelector("#ticket-from").textContent = activeRoute.from;
  document.querySelector("#ticket-to").textContent = activeRoute.to;
  document.querySelector("#ticket-stop").textContent = activeRoute.boarding;
  document.querySelector("#ticket-seat").textContent =
    selectedSeat || "Choose a seat";
  document.querySelector("#ticket-fare").textContent = "₹" + fare;
}

document.querySelector("#search-form").addEventListener("submit", function (event) {
  event.preventDefault();

  const origin = document.querySelector("#origin").value;
  const destination = document.querySelector("#destination").value;

  const route = routes.find(function (item) {
    return item.from === origin && item.to === destination;
  });

  if (route) {
    showRoute(route);
  } else {
    document.querySelector("#search-message").textContent =
      "No sample route for that pair yet. Try Narsapur to Medak Town.";
  }
});

seatButtons.forEach(function (button) {
  button.addEventListener("click", function () {
    seatButtons.forEach(function (seat) {
      seat.classList.remove("selected");
    });

    if (selectedSeat === button.dataset.seat) {
      selectedSeat = "";
    } else {
      selectedSeat = button.dataset.seat;
      button.classList.add("selected");
    }

    updateTicket();
  });
});

function changeSeatCount(amount) {
  availableSeats = Math.max(0, Math.min(20, availableSeats + amount));

  localStorage.setItem(
    "busbuddy-" + activeRoute.id,
    availableSeats
  );

  updateSeatCount();
}

document.querySelector("#board-one").addEventListener("click", function () {
  changeSeatCount(-1);
});

document.querySelector("#add-one").addEventListener("click", function () {
  changeSeatCount(1);
});

document.querySelector("#reset-demo").addEventListener("click", function () {
  localStorage.removeItem("busbuddy-" + activeRoute.id);
  showRoute(activeRoute);
});

document.querySelector("#print-ticket").addEventListener("click", function () {
  window.print();
});

showRoute(routes[0]);
